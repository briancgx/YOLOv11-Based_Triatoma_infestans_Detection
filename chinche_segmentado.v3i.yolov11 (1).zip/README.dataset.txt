# chinche_segmentado > 2025-02-19 9:04am
https://universe.roboflow.com/chinche/chinche_segmentado

Provided by a Roboflow user
License: CC BY 4.0

